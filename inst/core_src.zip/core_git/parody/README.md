# parody
parametric outlier dytection tools
