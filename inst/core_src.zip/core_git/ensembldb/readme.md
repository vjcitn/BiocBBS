
<p align = "center"><img src="https://github.com/jotsetung/BioC-stickers/blob/master/ensembldb/ensembldb.png" height="100"></p>

[![Years in Bioconductor](http://www.bioconductor.org/shields/years-in-bioc/ensembldb.svg)](http://www.bioconductor.org/packages/release/bioc/html/ensembldb.html)
[![Bioconductor release build status](http://www.bioconductor.org/shields/build/release/bioc/ensembldb.svg)](http://www.bioconductor.org/packages/release/bioc/html/ensembldb.html)
[![Bioconductor devel build status](http://www.bioconductor.org/shields/build/devel/bioc/ensembldb.svg)](http://www.bioconductor.org/checkResults/devel/bioc-LATEST/ensembldb.html)
[![Travis build result](https://travis-ci.org/jorainer/ensembldb.svg?branch=master)](https://travis-ci.org/jorainer/ensembldb)
[![codecov result](https://codecov.io/github/jorainer/ensembldb/coverage.svg?branch=master)](https://codecov.io/github/jorainer/ensembldb?branch=master)


# `ensembldb`: build and use Ensembl-based annotation packages

For more information please refer to
the [vignettes/ensembldb.org](vignettes/ensembldb.org) file.
