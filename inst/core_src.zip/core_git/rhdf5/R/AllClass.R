
setClass("H5IdComponent",
         representation(ID = "character", native = "logical")
)
