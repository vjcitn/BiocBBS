.test <- function() BiocGenerics:::testPackage("SummarizedExperiment")

