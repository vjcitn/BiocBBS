library(testthat)
library(SingleCellExperiment)
test_check("SingleCellExperiment")
